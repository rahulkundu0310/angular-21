import { ChangeDetectionStrategy, Component } from '@angular/core';

@Component({
  selector: 'platform-drawer',
  imports: [],
  templateUrl: './platform-drawer.html',
  styleUrl: './platform-drawer.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class PlatformDrawer {

}
