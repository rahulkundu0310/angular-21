import { ChangeDetectionStrategy, Component } from '@angular/core';

@Component({
  selector: 'reset-password',
  imports: [],
  templateUrl: './reset-password.html',
  styleUrl: './reset-password.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ResetPassword {

}
