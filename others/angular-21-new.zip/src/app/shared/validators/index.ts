export { passwordMatchValidator } from './password-match-validator';
