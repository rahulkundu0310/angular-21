interface Window {
	InstallTrigger?: unknown;
	clipboardData?: DataTransfer | null;
}

interface Screen {
	deviceXDPI?: number;
	deviceYDPI?: number;
}
