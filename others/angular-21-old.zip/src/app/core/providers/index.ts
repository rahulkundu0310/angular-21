export { provideLucideIcons } from './provide-lucide-icons';
export { provideNgxScrollbar } from './provide-ngx-scrollbar';
export { provideExceptionHandler } from './provide-exception-handler';
export { provideConfirmationService } from './provide-confirmation-service';
export { provideCachedRouteStrategy } from './provide-cached-route-strategy';
export { provideDocumentTitleStrategy } from './provide-document-title-strategy';
