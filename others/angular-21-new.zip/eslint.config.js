// @ts-check
import globals from 'globals';
import eslint from '@eslint/js';
import angular from 'angular-eslint';
import jsdoc from 'eslint-plugin-jsdoc';
import tseslint from 'typescript-eslint';
import { defineConfig } from 'eslint/config';
import pluginImport from 'eslint-plugin-import';
import eslintPluginPrettierRecommended from 'eslint-plugin-prettier/recommended';

export default defineConfig([
	// Excludes build output and tooling folders from lint passes to save time
	{ ignores: ['dist', '.angular', 'node_modules', 'coverage'] },

	// Groups strict parsing rules alongside formatting standards for codebase
	{
		files: ['**/*.ts'],
		processor: angular.processInlineTemplates,
		plugins: { jsdoc: jsdoc, import: pluginImport },
		languageOptions: {
			globals: { ...globals.browser, ...globals.node }
		},
		extends: [
			eslint.configs.recommended,
			...tseslint.configs.stylistic,
			...tseslint.configs.recommended,
			...angular.configs.tsRecommended
		],
		rules: {
			// Angular selector rules permit prefixes and enforce strict casing format
			'@angular-eslint/directive-selector': [
				'error',
				{
					prefix: [],
					type: 'attribute',
					style: 'camelCase'
				}
			],
			'@angular-eslint/component-selector': [
				'error',
				{
					prefix: [],
					type: 'element',
					style: 'kebab-case'
				}
			],

			// Angular quality rules lower risk patterns and encourage stable codebase
			'@angular-eslint/no-output-any': 'error',
			'@angular-eslint/use-lifecycle-interface': 'error',
			'@angular-eslint/use-injectable-provided-in': 'error',
			'@angular-eslint/prefer-on-push-component-change-detection': 'warn',

			// TypeScript rules favor strict typing and clean imports for safer builds
			'@typescript-eslint/no-explicit-any': 'warn',
			'@typescript-eslint/no-non-null-assertion': 'warn',
			'@typescript-eslint/explicit-function-return-type': 'off',
			'@typescript-eslint/no-unused-vars': ['warn', { argsIgnorePattern: '^_' }],
			'@typescript-eslint/consistent-type-imports': ['error', { prefer: 'type-imports' }],

			// JavaScript rules limit noise and enforce rigid spacing for clear output
			curly: 'off',
			'no-console': 'warn',
			'no-unused-vars': 'off',
			'no-multiple-empty-lines': ['error', { max: 2, maxEOF: 1 }],
			'spaced-comment': ['error', 'always', { markers: ['/'], block: { balanced: true } }],

			// Import order groups paths keeping stable alphabet list for rapid search
			'import/prefer-default-export': 'off',
			'import/order': [
				'warn',
				{
					'newlines-between': 'always',
					alphabetize: { order: 'asc', caseInsensitive: true },
					groups: [['builtin', 'external', 'internal', 'parent', 'sibling', 'index']],
					pathGroups: [
						{ pattern: '@features/**', group: 'internal', position: 'before' },
						{ pattern: '@widgets/**', group: 'internal', position: 'before' },
						{ pattern: '@skeletons/**', group: 'internal', position: 'before' },
						{ pattern: '@fallbacks/**', group: 'internal', position: 'before' }
					]
				}
			],

			// JSDoc rules enforce tags alignment and maintain block indentation depth
			'jsdoc/check-alignment': 'warn',
			'jsdoc/check-indentation': 'warn',
			'jsdoc/require-param-type': 'off',
			'jsdoc/require-returns-type': 'off'
		}
	},
	{
		files: ['**/*.html'],
		extends: [...angular.configs.templateRecommended, ...angular.configs.templateAccessibility],
		rules: {
			'@angular-eslint/template/eqeqeq': 'error',
			'@angular-eslint/template/no-any': 'warn'
		}
	},

	// Prettier hook applies formatting rules and parses external style config
	eslintPluginPrettierRecommended
]);
