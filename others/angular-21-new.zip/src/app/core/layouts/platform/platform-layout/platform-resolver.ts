import { inject } from '@angular/core';
import { ResolveFn } from '@angular/router';
import { of, switchMap, timer } from 'rxjs';
import { PlatformStore } from '../platform-store';
import { menuItemsConfig } from '@/src/app/configs';

export const platformResolver: ResolveFn<any> = (route, state) => {
	const platformStore = inject(PlatformStore);

	return timer(100).pipe(
		switchMap(() => {
			platformStore.setMenuItems(menuItemsConfig);
			return of(null);
		})
	);
};
